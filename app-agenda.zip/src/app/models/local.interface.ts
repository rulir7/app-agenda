export interface Local {
  id?: number;
  nome: string;
  endereco: string;
}
