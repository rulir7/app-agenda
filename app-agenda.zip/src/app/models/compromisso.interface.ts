export interface Compromisso {
  id?: number;
  titulo: string;
  descricao: string;
  data: string;
  hora: string;
  contatoId: number;
  localId: number;
  usuarioId: number;
  userId: string;
}
