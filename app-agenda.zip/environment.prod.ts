export const environment = {
  production: true,
  apiUrl: '/api',
  //  'http://ip172-18-0-74-cvqr8igl2o9000d23kpg-3000.direct.labs.play-with-docker.com',
};
